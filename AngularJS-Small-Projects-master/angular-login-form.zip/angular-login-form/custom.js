var mymodule = angular.module('webT',[]); //create a module: is container of different part of page.
mymodule.controller("mycontroller", function($scope){
    // alert("hello world.....");
    $scope.cityName = "Delhi";
    $scope.fname = "Silver";

    $scope.details = function(){
        return "This is function variable:" + " " + $scope.fname;
    };
});